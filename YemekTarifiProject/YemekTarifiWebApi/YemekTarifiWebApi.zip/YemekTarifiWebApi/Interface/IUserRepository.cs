﻿using YemekTarifiWebApi.Model;

namespace YemekTarifiWebApi.Interface
{
    public interface IUserRepository:IRepository<User>
    {

    }
}
