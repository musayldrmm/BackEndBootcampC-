﻿using YemekTarifiWebApi.Model;

namespace YemekTarifiWebApi.Interface
{
    public interface IProductRepository:IRepository<Product>
    {
    }
}
