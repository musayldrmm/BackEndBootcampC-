﻿using YemekTarifiWebApi.Model;

namespace YemekTarifiWebApi.Interface
{
    public interface ICategoryRepository:IRepository<Category>
    {
    }
}
